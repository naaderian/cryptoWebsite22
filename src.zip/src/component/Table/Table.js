import React from 'react'
import './Table.css'
function Table() {
    return (
       
      <div className="divTable">

             <div className="divRow">
                <div className="divCell">#</div>
                <div  className="divCell">Name</div>
                <div  className="divCell">Price</div>
                <div  className="divCell">24h %</div>
                <div  className="divCell">7d %</div>
                <div  className="divCell">Market Cap</div>
                <div  className="divCell">Volume(24h)</div>
                <div  className="divCell">Circulating Supply</div>
                <div  className="divCell">Last 7 Days</div>
             </div>
            <div className="divRow">
            <div className="divCell">#</div>
                <div  className="divCell">Name</div>
                <div  className="divCell">Price</div>
                <div  className="divCell">24h %</div>
                <div  className="divCell">7d %</div>
                <div  className="divCell">Market Cap</div>
                <div  className="divCell">Volume(24h)</div>
                <div  className="divCell">Circulating Supply</div>
                <div  className="divCell">Last 7 Days</div>
            </div>
            <div className="divRow">
            <div className="divCell">#</div>
                <div  className="divCell">Name</div>
                <div  className="divCell">Price</div>
                <div  className="divCell">24h %</div>
                <div  className="divCell">7d %</div>
                <div  className="divCell">Market Cap</div>
                <div  className="divCell">Volume(24h)</div>
                <div  className="divCell">Circulating Supply</div>
                <div  className="divCell">Last 7 Days</div>
           </div>
            <div className="divRow">
            <div className="divCell">#</div>
                <div  className="divCell">Name</div>
                <div  className="divCell">Price</div>
                <div  className="divCell">24h %</div>
                <div  className="divCell">7d %</div>
                <div  className="divCell">Market Cap</div>
                <div  className="divCell">Volume(24h)</div>
                <div  className="divCell">Circulating Supply</div>
                <div  className="divCell">Last 7 Days</div>
           </div>

      </div> 
    )
}

export default Table
